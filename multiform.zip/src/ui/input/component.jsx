import { Fragment, forwardRef, useCallback, useState } from "react";
import cls from "./style.module.scss";
import cn from "classnames";
import { FieldWrapper } from "../fieldWrapper";

export const Input = forwardRef(
  (
    {
      id,
      type = "text",
      disabled,
      readOnly,
      classname,
      error,
      succes,
      block,
      value,
      defaultValue,
      htmlTitle,
      placeholder,
      ...restProps
    },
    ref
  ) => {
    const uncontrolled = value === undefined;

    const [stateValue, setStateValue] = useState(defaultValue || "");

    const handleBlur = useCallback((event) => {}, []);

    const handleInputFocus = useCallback((event) => {}, []);

    const handleInputChange = useCallback((event) => {}, []);

    const handleClear = useCallback((event) => {}, []);

    return (
      <FieldWrapper htmlTitle={htmlTitle}>
        <input
          ref={ref}
          id={id}
          className={cn(cls.input, {
            [cls.error]: error,
            [cls.succes]: succes,
            [cls.block]: block,
          })}
          type={type}
          disabled={disabled}
          onBlur={handleBlur}
          onFocus={handleInputFocus}
          onChange={handleInputChange}
          value={value}
          readOnly={readOnly}
          placeholder={placeholder}
          {...restProps}
        />
        {error && <div>{error}</div>}
      </FieldWrapper>
    );
  }
);
