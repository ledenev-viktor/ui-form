import cn from "classnames";
import cls from "./step.module.scss";
import { Fragment } from "react";

export const Step = ({ count, countLength, step }) => {
  const fields = step.fields ? step.fields : [];
  return (
    <>
      {fields.map((field, index) => (
        <Fragment key={index}>{field}</Fragment>
      ))}
    </>
  );
};
