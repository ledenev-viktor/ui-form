export const Checmark = () => {
  return (
    <svg
      width="14"
      height="11"
      viewBox="0 0 14 11"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M4.84339 10.7059L0 5.61288L1.02455 4.5355L4.84339 8.55115L12.9754 0L14 1.07738L4.84339 10.7059Z"
        fill="#2D3031"
      />
    </svg>
  );
};
