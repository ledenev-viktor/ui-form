import { LayoutPage } from "./layoutPage/layoutPage";

export { LayoutPage };
