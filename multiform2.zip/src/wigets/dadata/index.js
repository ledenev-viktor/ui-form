export { Dadata } from "./component";
